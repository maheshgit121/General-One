<html>
<title>Login Verification</title>
<style>
body {
  color: green;
  background-color: #E6E6FA;
  font-size: 14
}
</style>
<body>
<br>
<h1>Welcome <?php echo $_GET["name"]; ?></h1><br>
<h2><?php 

$un = trim($_GET["name"]);
$pw = trim($_GET["pass"]);

if($un == "maheshcharaj@gmail.com" && $pw == "test@123")
{
echo "Login Successfull";
}
else
{
echo '<h2 style="color:red;">Invalid Credentials</h2>';
}
?></h2>
</body>
</html>